export {default as Logo} from "./etherpillar.png";
export {default as LogoBlack} from "./etherpillar-black.png";
export {default as Test} from "./test.png";
export {default as etp1} from "./etp1.png";
export {default as etp2} from "./etp2.png";
export {default as etp3} from "./etp3.png";