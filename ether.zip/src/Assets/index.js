export {default as Logo} from "./etherpillar.png";
export {default as LogoBlack} from "./etherpillar-black.png";
export {default as Test} from "./test.png";